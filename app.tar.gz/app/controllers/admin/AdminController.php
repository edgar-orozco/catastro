<?php
/*
|--------------------------------------------------------------------------
| AdminController base controller
|--------------------------------------------------------------------------
|
*/

class AdminController extends BaseController
{
    /**
     * Initializer.
     *
     * @return \AdminController
     */
    public function __construct()
    {
        parent::__construct();
    }

}
