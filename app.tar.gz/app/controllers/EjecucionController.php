<?php
class EjecucionController extends BaseController
{
	public function buscar()
	{
		
		return View::make('ejecucion.principal');
	}
}
