<?php
return array(
    "copias" => "copia | copias ",
    "certificadas" => "certificada | certificadas ",

);