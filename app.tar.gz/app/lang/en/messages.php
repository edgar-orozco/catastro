<?php
return array(
    "copias" => "copy | copies",
);