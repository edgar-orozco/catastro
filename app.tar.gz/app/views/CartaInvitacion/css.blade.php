<html>
<header>
{{ HTML::style('assets/css/pdf-css.css') }}
</header>
<body>
<p>Laravel is <span>beautiful</span> !</p>
</body>
</html>