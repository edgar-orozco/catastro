<div class="form-group">
 	
    {{Form::file('file', ['id'=>'file', 'autofocus'=> 'autofocus', 'required' => 'required', 'tb-focus' => 'focusForm', 'ng-blur' => 'focusForm = false'])}}

</div>



