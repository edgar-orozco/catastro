<?php

//Rutas para login, logout y profile, es decir, control de sesión.
Route::controller('users', 'UsersController');
