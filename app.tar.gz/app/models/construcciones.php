<?php

class construcciones extends Eloquent
{
    protected $table ='construcciones';
    protected $primaryKey = 'gid';
    public $timestamps=true;
   // protected $guarded = array("*");
    //protected $fillable = array("clave","uso_construccion","sup_const");

}


