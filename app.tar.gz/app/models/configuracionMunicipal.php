<?php
class configuracionMunicipal extends Eloquent {

    protected $table = 'configuracion_municipal';
    protected $primaryKey = 'id_configuracion';
    public $timestamps = false;
}
