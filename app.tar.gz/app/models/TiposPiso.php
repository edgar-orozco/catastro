<?php

class TiposPiso extends Eloquent
{
    protected $table ='tipopisos';
    protected $primaryKey = 'id_tipopiso';
    public $timestamps=false;                                            
}
