<?php

class TipoGiros Extends Eloquent
{
    protected $table = 'tipogiros';
    protected $primaryKey = 'id_tipogiro';
    public $timestamps = false;
}

