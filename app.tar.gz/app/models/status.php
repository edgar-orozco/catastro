<?php
class status extends Eloquent {

    protected $table = 'cat_status';
    protected $primaryKey = 'id_status';
    public $timestamps = false;
    
}
