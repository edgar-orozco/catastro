<?php

class UsoConstruccion Extends Eloquent
{
    protected $table = 'tiposusosconstruccion';
    protected $primaryKey = 'id_tuc';
    public $timestamps = false;
}

