<?php


class VentanasConstruccion extends Eloquent
{
    protected $table ='ventanasconstruccion';
    protected $primaryKey = 'id';
    public $timestamps=false;
   // protected $guarded = array("*");
   //protected $fillable = array("clave","uso_construccion","sup_const"); 
//                                              
}


