<?php


class Conf extends Eloquent {

	
	protected $table = 'conf';
}

