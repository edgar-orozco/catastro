<?php


class TipoImagenes extends Eloquent
{
    protected $table ='tipoimagenes';
    protected $primaryKey = 'id_tipoimagen';
    public $timestamps=true;
   // protected $guarded = array("*");
   //protected $fillable = array("clave","uso_construccion","sup_const"); 
//                                              
}


