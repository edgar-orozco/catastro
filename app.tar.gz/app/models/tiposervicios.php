<?php
class tiposervicios extends Eloquent
{
    protected $table ='tiposervicios';
    protected $primaryKey = 'id_tiposervicio';
    public $timestamps=false;
}

