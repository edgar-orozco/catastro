<?php


class ImagenesLevantamiento extends Eloquent
{
    protected $table ='imageneslevantamiento';
    protected $primaryKey = 'id_il';
    public $timestamps=true;
   // protected $guarded = array("*");
   //protected $fillable = array("clave","uso_construccion","sup_const"); 
//                                              
}


