<?php

class TomasAgua Extends Eloquent
{
    protected $table = 'tomasagua';
    protected $primaryKey = 'gid';
    public $timestamps = true;
}

