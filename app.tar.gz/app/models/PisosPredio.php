<?php

class PisosPredio extends Eloquent
{
    protected $table ='pisospredio';
    protected $primaryKey = 'id_pisopredio';
    public $timestamps=false;                                            
}
