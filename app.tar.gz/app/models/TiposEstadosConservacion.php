<?php
class TiposEstadosConservacion extends Eloquent
{
    protected $table ='tiposestadosconservacion';
    protected $primaryKey = 'id_tec';
    public $timestamps=false;
                                            
}

