<?php
use LaravelBook\Ardent\Ardent;

class UbicacionFiscal extends Ardent
{
    protected $table = 'ubicacion_fiscal';

}