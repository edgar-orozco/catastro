<?php

class TiposClaseConstruccion extends Eloquent
{
    protected $table ='tiposclasesconstruccion';
    protected $primaryKey = 'id_tcc';
    public $timestamps=false;
                                            
}