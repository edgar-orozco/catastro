<?php

class TiposTechos Extends Eloquent
{
    protected $table = 'tipostechosconstruccion';
    protected $primaryKey = 'id_ttc';
    public $timestamps = false;
}
