<?php
class servicios extends Eloquent {
    protected $table = 'serviciospredio';
    protected $primaryKey = 'id_serviciopredio';
    public $timestamps = true;
}

