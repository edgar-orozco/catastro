<?php

class EstatusTramite extends \Eloquent {
	protected $fillable = ['nombre', 'descripcion', 'presente', 'pasado', 'orden'];

}